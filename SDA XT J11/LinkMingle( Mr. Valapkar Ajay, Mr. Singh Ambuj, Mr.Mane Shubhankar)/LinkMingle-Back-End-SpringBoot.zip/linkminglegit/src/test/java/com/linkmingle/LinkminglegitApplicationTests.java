package com.linkmingle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkminglegitApplicationTests {

	@Test
	void contextLoads() {
	}

}
